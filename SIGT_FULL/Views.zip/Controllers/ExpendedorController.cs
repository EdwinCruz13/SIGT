﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SIGT_FULL.Controllers
{
    public class ExpendedorController : Controller
    {
        // GET: Expendedor
        /// <summary>
        /// vista que muestra el expendedor de ticket
        /// </summary>
        /// <param name="IP"></param>
        /// <returns></returns>
        public ActionResult Index(string IP)
        {

            //validar que contenga la ip
            if (IP == null)
                return RedirectToAction("Index", "Home");

            //obtener la IP y almacenarlo en ViewBag
            ViewBag.IP = IP;


            return View();
        }


        /// <summary>
        /// seleccion de visita, recibira
        /// de parametros la cedula de la persona
        /// </summary>
        /// <returns></returns>
        public ActionResult SeleccionVisita()
        {
            return View();
        }





        public ActionResult _Paso1()
        {
            return PartialView();
        }
    }
}